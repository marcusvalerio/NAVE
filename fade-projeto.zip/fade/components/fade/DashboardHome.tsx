'use client'

import Link from 'next/link'

export default function DashboardHome({ nome }: { nome: string }) {
  const hora = new Date().getHours()
  const saudacao = hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite'

  const stats = [
    { label: 'Conteudos', value: '0', sub: 'criados', accent: true },
    { label: 'Marca', value: '—', sub: 'nao configurada' },
    { label: 'Campanhas', value: '0', sub: 'ativas' },
    { label: 'Planejamento', value: '0%', sub: 'concluido' },
  ]

  const checklist = [
    { label: 'Conta criada', done: true },
    { label: 'Marca configurada', done: false },
    { label: 'Primeiro conteudo criado', done: false },
    { label: 'Primeiro planejamento criado', done: false },
  ]

  const donePct = Math.round((checklist.filter(i => i.done).length / checklist.length) * 100)

  return (
    <main style={{ flex: 1, padding: '24px 20px 100px', maxWidth: 600, margin: '0 auto', width: '100%', animation: 'fadeIn 0.4s ease' }}>

      {/* Saudação */}
      <div style={{ marginBottom: 28, padding: '20px', background: 'linear-gradient(135deg, rgba(59,130,246,0.06) 0%, transparent 100%)', border: '1px solid var(--border)', borderRadius: 12 }}>
        <div style={{ fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 4 }}>
          {saudacao}
        </div>
        <div className="font-display" style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>
          {nome}.
        </div>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
          Sua estrategia esta sendo construida.
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 24 }}>
        {stats.map((s) => (
          <div key={s.label} style={{
            background: 'var(--surface)',
            border: `1px solid ${s.accent ? 'rgba(59,130,246,0.28)' : 'var(--border)'}`,
            borderRadius: 10,
            padding: 16,
            background: s.accent ? 'linear-gradient(135deg, rgba(59,130,246,0.08), transparent)' : 'var(--surface)',
          }}>
            <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 8 }}>
              {s.label}
            </div>
            <div className="font-display" style={{ fontSize: 28, fontWeight: 700, lineHeight: 1, color: s.accent ? 'var(--accent)' : 'var(--text)', marginBottom: 4 }}>
              {s.value}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Proximo passo */}
      <Link href="/marca" style={{ textDecoration: 'none' }}>
        <div style={{
          background: 'var(--surface)',
          border: '1px solid rgba(59,130,246,0.28)',
          borderRadius: 10,
          padding: 16,
          display: 'flex',
          alignItems: 'center',
          gap: 14,
          marginBottom: 24,
          cursor: 'pointer',
          transition: 'border-color 0.2s',
        }}>
          <div style={{ width: 10, height: 10, background: 'var(--accent)', borderRadius: '50%', boxShadow: '0 0 10px rgba(59,130,246,0.5)', flexShrink: 0 }}></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 3 }}>Proximo passo</div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>Configurar sua marca</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Nome, posicionamento, tom de voz e publico</div>
          </div>
          <div style={{ color: 'var(--accent)', fontSize: 16 }}>→</div>
        </div>
      </Link>

      {/* Checklist */}
      <div style={{ marginBottom: 24 }}>
        <div className="font-display" style={{ fontSize: 16, fontWeight: 600, marginBottom: 12 }}>Sua evolucao</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
          <span>{donePct}% concluido</span>
          <span>{checklist.filter(i => i.done).length} de {checklist.length}</span>
        </div>
        <div style={{ height: 2, background: 'var(--border)', borderRadius: 2, marginBottom: 16, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${donePct}%`, background: 'var(--accent)', boxShadow: '0 0 8px rgba(59,130,246,0.5)', borderRadius: 2, transition: 'width 0.6s ease' }}></div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {checklist.map((item) => (
            <div key={item.label} style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              padding: '12px 14px',
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: 6,
              opacity: item.done ? 0.6 : 1,
            }}>
              <div style={{
                width: 20, height: 20,
                borderRadius: '50%',
                background: item.done ? 'var(--success)' : 'transparent',
                border: item.done ? 'none' : '1.5px solid var(--border-hover)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}>
                {item.done && (
                  <svg width="10" height="8" viewBox="0 0 12 10" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="1 5 4 8 11 1"/>
                  </svg>
                )}
              </div>
              <div style={{ fontSize: 13, color: 'var(--text)', textDecoration: item.done ? 'line-through' : 'none' }}>
                {item.label}
              </div>
              {item.done && (
                <div style={{ marginLeft: 'auto', fontSize: 10, padding: '2px 8px', borderRadius: 4, background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.25)', color: '#22c55e' }}>
                  Feito
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

    </main>
  )
}
