'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      setError('Email ou senha incorretos.')
      setLoading(false)
      return
    }

    router.push('/dashboard')
    router.refresh()
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-12"
      style={{ background: 'radial-gradient(ellipse at top, rgba(59,130,246,0.04) 0%, #0a0a0a 60%)' }}>

      {/* Logo */}
      <div className="mb-12 text-center">
        <div className="font-logo text-xl font-bold tracking-widest mb-1">
          FADE<span style={{ color: '#3b82f6' }}>.</span>
        </div>
        <div className="text-xs tracking-widest uppercase" style={{ color: 'var(--text-muted)', letterSpacing: '0.16em' }}>
          by MEJI
        </div>
      </div>

      {/* Card */}
      <div className="w-full max-w-sm">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-bold mb-2">Entrar na plataforma</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>
            Seu marketing continua de onde parou.
          </p>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div>
            <label className="field-label">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              className="field-input"
            />
          </div>

          <div>
            <label className="field-label">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="field-input"
            />
          </div>

          {error && (
            <div className="error-msg">{error}</div>
          )}

          <button type="submit" disabled={loading} className="btn-primary mt-2">
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>

        <p className="text-center mt-6" style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
          Ainda nao tem conta?{' '}
          <Link href="/cadastro" style={{ color: 'var(--accent)' }}>
            Criar conta
          </Link>
        </p>
      </div>
    </div>
  )
}
