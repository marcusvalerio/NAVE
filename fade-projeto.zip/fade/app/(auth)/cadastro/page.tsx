'use client'

import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

export default function CadastroPage() {
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const [error, setError] = useState('')

  async function handleCadastro(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { nome },
        emailRedirectTo: `${location.origin}/auth/callback`,
      },
    })

    if (error) {
      setError('Erro ao criar conta. Tente novamente.')
      setLoading(false)
      return
    }

    setDone(true)
  }

  if (done) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 py-12 text-center"
        style={{ background: 'radial-gradient(ellipse at top, rgba(59,130,246,0.04) 0%, #0a0a0a 60%)' }}>
        <div className="font-logo text-xl font-bold tracking-widest mb-12">
          FADE<span style={{ color: '#3b82f6' }}>.</span>
        </div>
        <div style={{
          width: 56, height: 56,
          background: 'rgba(34,197,94,0.1)',
          border: '1px solid rgba(34,197,94,0.25)',
          borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 20px'
        }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        <h1 className="font-display text-2xl font-bold mb-3">Conta criada.</h1>
        <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.7, maxWidth: 280 }}>
          Enviamos um link de confirmacao para <strong style={{ color: 'var(--text)' }}>{email}</strong>. Confirme para acessar a plataforma.
        </p>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-12"
      style={{ background: 'radial-gradient(ellipse at top, rgba(59,130,246,0.04) 0%, #0a0a0a 60%)' }}>

      <div className="mb-12 text-center">
        <div className="font-logo text-xl font-bold tracking-widest mb-1">
          FADE<span style={{ color: '#3b82f6' }}>.</span>
        </div>
        <div className="text-xs tracking-widest uppercase" style={{ color: 'var(--text-muted)', letterSpacing: '0.16em' }}>
          by MEJI
        </div>
      </div>

      <div className="w-full max-w-sm">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-bold mb-2">Criar sua conta</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>
            Seu sistema de marketing esta pronto para ser configurado.
          </p>
        </div>

        <form onSubmit={handleCadastro} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div>
            <label className="field-label">Nome</label>
            <input
              type="text"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Seu nome"
              required
              className="field-input"
            />
          </div>

          <div>
            <label className="field-label">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              className="field-input"
            />
          </div>

          <div>
            <label className="field-label">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimo 8 caracteres"
              minLength={8}
              required
              className="field-input"
            />
          </div>

          {error && (
            <div className="error-msg">{error}</div>
          )}

          <button type="submit" disabled={loading} className="btn-primary mt-2">
            {loading ? 'Criando conta...' : 'Criar conta'}
          </button>
        </form>

        <p className="text-center mt-6" style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
          Ja tem conta?{' '}
          <Link href="/login" style={{ color: 'var(--accent)' }}>
            Entrar
          </Link>
        </p>
      </div>
    </div>
  )
}
