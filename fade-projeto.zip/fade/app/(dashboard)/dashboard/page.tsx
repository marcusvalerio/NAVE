import { createClient } from '@/lib/supabase/server'
import DashboardHome from '@/components/fade/DashboardHome'

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const nome = user?.user_metadata?.nome || user?.email?.split('@')[0] || 'usuario'

  return <DashboardHome nome={nome} />
}
