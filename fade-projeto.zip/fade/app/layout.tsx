import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'FADE — Marketing para barbearias',
  description: 'Planejamento, posicionamento e consistência. Seu marketing sem improviso.',
  manifest: '/manifest.json',
  themeColor: '#0a0a0a',
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}
