import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bg: '#0a0a0a',
        surface: '#111111',
        'surface-2': '#161616',
        'surface-3': '#1a1a1a',
        border: '#1e1e1e',
        'border-hover': '#303030',
        accent: '#3b82f6',
        success: '#22c55e',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Funnel Display', 'sans-serif'],
        logo: ['Space Grotesk', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

export default config
